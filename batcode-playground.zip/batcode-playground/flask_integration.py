"""Flask Application Hardening and Optimization Integration
Applies security hardening and performance optimizations to Flask app.
"""

import time
from functools import wraps

from flask import g, jsonify, request
from performance_optimization import (
    async_queue,
    general_cache,
    query_cache,
    response_cache,
)
from security_hardening import (
    ddos_protection,
    rate_limiter,
    require_rate_limit,
    secure_config,
    security_headers,
)


def setup_flask_hardening(app):
    """Complete Flask application hardening setup.
    Call this function after creating Flask app and before registering routes.

    Usage:
        app = Flask(__name__)
        setup_flask_hardening(app)
    """
    # 1. Security Configuration
    secure_config(app)

    # 2. Request/Response Middleware

    @app.before_request
    def check_security():
        """Pre-request security checks."""
        # DDoS protection check
        if not ddos_protection.analyze_request_pattern(request.remote_addr):
            return jsonify({"error": "Too many requests"}), 429

        # Store request start time for performance monitoring
        g.request_start_time = time.time()

        # Validate content type for POST requests
        if request.method in ["POST", "PUT", "PATCH"]:
            if not request.is_json and request.form is None:
                return jsonify({"error": "Invalid content type"}), 415
        return None

    @app.after_request
    def apply_security_headers(response):
        """Apply security headers to all responses."""
        # Apply security headers
        security_headers.apply_to_response(response)

        # Add performance monitoring headers
        if hasattr(g, "request_start_time"):
            elapsed = time.time() - g.request_start_time
            response.headers["X-Response-Time"] = f"{elapsed:.3f}s"

        # Add cache control headers based on content type
        if response.content_type and "text/html" in response.content_type:
            response.headers["Cache-Control"] = "public, max-age=3600"
        elif response.content_type and any(
            ct in response.content_type
            for ct in [
                "image/",
                "font/",
                "application/javascript",
                "text/css",
            ]
        ):
            response.headers["Cache-Control"] = "public, max-age=31536000"  # 1 year

        # Add additional security headers
        response.headers["X-Permitted-Cross-Domain-Policies"] = "none"
        response.headers["X-DNS-Prefetch-Control"] = "off"

        return response

    @app.errorhandler(429)
    def ratelimit_handler(e):
        """Handle rate limit exceeded."""
        return jsonify({"error": "Rate limit exceeded", "retry_after": 60}), 429

    @app.errorhandler(400)
    def bad_request_handler(e):
        """Handle bad requests."""
        return jsonify({"error": "Bad request"}), 400

    @app.errorhandler(403)
    def forbidden_handler(e):
        """Handle forbidden requests."""
        return jsonify({"error": "Forbidden"}), 403

    @app.errorhandler(404)
    def not_found_handler(e):
        """Handle not found requests."""
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(500)
    def internal_error_handler(e):
        """Handle internal server errors."""
        # Log the error (in production, send to monitoring service)
        return jsonify({"error": "Internal server error"}), 500

    # 3. Add debugging/monitoring endpoints (only in development)
    if app.debug:

        @app.route("/api/admin/cache-stats")
        def cache_stats():
            """Get cache statistics (development only)."""
            return jsonify(
                {
                    "general_cache": general_cache.get_stats(),
                    "rate_limiter": {
                        "tracked_ips": len(rate_limiter.ip_requests),
                        "blocked_ips": len(rate_limiter.blocked_ips),
                    },
                },
            )

        @app.route("/api/admin/performance")
        def performance_stats():
            """Get performance statistics (development only)."""
            return jsonify(
                {
                    "cache": general_cache.get_stats(),
                    "query_cache": query_cache.cache.get_stats(),
                    "async_queue_size": len(async_queue.queue),
                },
            )

    # 4. Start async task queue
    async_queue.start()

    return app


def add_rate_limited_route(app, route, methods=None, limit=100, window=60):
    """Decorator factory for adding rate-limited routes.

    Usage:
        @add_rate_limited_route(app, '/api/data', limit=10, window=60)
        def get_data():
            return jsonify({'data': []})
    """
    if methods is None:
        methods = ["GET"]

    def decorator(f):
        @require_rate_limit(rate_limiter, limit, window)
        @wraps(f)
        def decorated_function(*args, **kwargs):
            return f(*args, **kwargs)

        app.add_url_rule(route, f.__name__, decorated_function, methods=methods)
        return decorated_function

    return decorator


def get_client_info():
    """Get client information from request."""
    return {
        "ip": rate_limiter.get_client_ip(),
        "user_agent": request.headers.get("User-Agent", "Unknown"),
        "referer": request.headers.get("Referer", "Direct"),
        "country": request.headers.get("CF-IPCountry", "Unknown"),
    }


def log_security_event(event_type, details=None):
    """Log security-related events for monitoring."""
    event = {
        "timestamp": time.time(),
        "type": event_type,
        "client": get_client_info(),
        "details": details or {},
    }

    # In production, send to monitoring/logging service
    # For now, store in async queue
    async_queue.enqueue(lambda: print(f"Security Event: {event}"))


def validate_and_sanitize_input(data, schema):
    """Validate and sanitize user input against schema.

    Args:
        data: Dictionary of input data
        schema: Dictionary mapping field names to validation functions

    Returns:
        (valid, sanitized_data) tuple

    """
    sanitized = {}

    for field, validator in schema.items():
        if field not in data:
            return False, None

        value = validator(data[field])
        if value is None:
            return False, None

        sanitized[field] = value

    return True, sanitized


class CacheManager:
    """Manager for application-wide caching."""

    @staticmethod
    def cache_view(ttl=300):
        """Decorator for caching view responses."""

        def decorator(f):
            @wraps(f)
            def decorated_function(*args, **kwargs):
                # Skip caching for non-GET requests
                if request.method != "GET":
                    return f(*args, **kwargs)

                # Generate cache key from path and query params
                cache_key = f"{request.path}:{request.query_string.decode()}"

                cached = general_cache.get(cache_key)
                if cached is not None:
                    return cached

                result = f(*args, **kwargs)
                general_cache.set(cache_key, result, ttl)
                return result

            return decorated_function

        return decorator

    @staticmethod
    def invalidate_cache(pattern=None):
        """Invalidate cache entries."""
        if pattern is None:
            general_cache.clear()
            query_cache.invalidate()
            response_cache.cache.clear()
        else:
            query_cache.invalidate(pattern)

    @staticmethod
    def preload_cache(key_value_pairs, ttl=300):
        """Preload cache with values."""
        for key, value in key_value_pairs.items():
            general_cache.set(key, value, ttl)


class AdminTools:
    """Administrative tools for site management."""

    @staticmethod
    def get_security_status():
        """Get current security status."""
        return {
            "rate_limiter": {
                "tracked_ips": len(rate_limiter.ip_requests),
                "blocked_ips": len(rate_limiter.blocked_ips),
                "global_limit": rate_limiter.global_limit,
            },
            "cache": {
                "general": general_cache.get_stats(),
                "query": query_cache.cache.get_stats(),
                "response": {
                    "cached_responses": len(response_cache.cache.cache),
                },
            },
            "performance": {
                "async_tasks": len(async_queue.queue),
                "timestamp": time.time(),
            },
        }

    @staticmethod
    def reset_rate_limits():
        """Reset all rate limiting."""
        rate_limiter.ip_requests.clear()
        rate_limiter.blocked_ips.clear()

    @staticmethod
    def block_ip(ip, duration=3600):
        """Manually block an IP address."""
        rate_limiter.block_ip(ip, duration)

    @staticmethod
    def unblock_ip(ip):
        """Manually unblock an IP address."""
        if ip in rate_limiter.blocked_ips:
            del rate_limiter.blocked_ips[ip]

    @staticmethod
    def get_blocked_ips():
        """Get list of blocked IPs."""
        current_time = time.time()
        return [
            {
                "ip": ip,
                "blocked_until": unblock_time,
                "remaining_seconds": max(0, unblock_time - current_time),
            }
            for ip, unblock_time in rate_limiter.blocked_ips.items()
            if unblock_time > current_time
        ]


def create_admin_blueprint():
    """Create admin blueprint for security/performance management."""
    from flask import Blueprint

    admin = Blueprint("admin", __name__, url_prefix="/api/admin")

    # Security routes (require admin token)
    @admin.route("/security-status")
    def security_status():
        """Get security status."""
        return jsonify(AdminTools.get_security_status())

    @admin.route("/blocked-ips")
    def get_blocked_ips():
        """Get blocked IPs."""
        return jsonify(AdminTools.get_blocked_ips())

    @admin.route("/cache-clear", methods=["POST"])
    def cache_clear():
        """Clear cache."""
        CacheManager.invalidate_cache()
        return jsonify({"status": "Cache cleared"})

    @admin.route("/performance-report")
    def performance_report():
        """Get performance report."""
        return jsonify(
            {
                "cache_stats": general_cache.get_stats(),
                "query_cache_stats": query_cache.cache.get_stats(),
                "rate_limiter_stats": {
                    "tracked_ips": len(rate_limiter.ip_requests),
                    "blocked_ips": len(rate_limiter.blocked_ips),
                },
            },
        )

    return admin


# Shutdown handler
def cleanup_on_shutdown(app):
    """Cleanup resources on application shutdown."""

    @app.teardown_appcontext
    def shutdown(exception=None):
        async_queue.stop()
