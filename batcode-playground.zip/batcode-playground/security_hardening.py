"""Security Hardening and Performance Optimization Module
Provides protection against:
- High volume traffic attacks
- SQL injection
- XSS attacks
- CSRF attacks
- DDoS attacks
- Unauthorized access
- Rate limiting violations
- Session hijacking.
"""

import contextlib
import hashlib
import hmac
import os
import secrets
import time
from collections import defaultdict
from datetime import timedelta
from functools import wraps

from flask import jsonify, request


class RateLimiter:
    """Advanced rate limiter with per-IP, per-endpoint tracking and DDoS detection."""

    def __init__(self, global_limit=1000, window_size=60):
        """Args:
        global_limit: Max requests per window globally
        window_size: Time window in seconds.

        """
        self.global_limit = global_limit
        self.window_size = window_size
        self.ip_requests = defaultdict(list)
        self.endpoint_requests = defaultdict(lambda: defaultdict(list))
        self.blocked_ips = {}
        self.last_cleanup = time.time()

    def cleanup_old_entries(self):
        """Remove expired entries from memory (runs every 100 calls)."""
        now = time.time()
        if now - self.last_cleanup < 60:  # Run cleanup every 60 seconds
            return

        # Clean IP requests
        for ip in list(self.ip_requests.keys()):
            self.ip_requests[ip] = [
                req_time
                for req_time in self.ip_requests[ip]
                if now - req_time < self.window_size
            ]
            if not self.ip_requests[ip]:
                del self.ip_requests[ip]

        # Clean endpoint requests
        for endpoint in list(self.endpoint_requests.keys()):
            for ip in list(self.endpoint_requests[endpoint].keys()):
                self.endpoint_requests[endpoint][ip] = [
                    req_time
                    for req_time in self.endpoint_requests[endpoint][ip]
                    if now - req_time < self.window_size
                ]
                if not self.endpoint_requests[endpoint][ip]:
                    del self.endpoint_requests[endpoint][ip]
            if not self.endpoint_requests[endpoint]:
                del self.endpoint_requests[endpoint]

        # Clean blocked IPs
        self.blocked_ips = {
            ip: unblock_time
            for ip, unblock_time in self.blocked_ips.items()
            if unblock_time > now
        }

        self.last_cleanup = now

    def get_client_ip(self):
        """Extract real client IP (handles proxies)."""
        if request.headers.get("X-Forwarded-For"):
            return request.headers.get("X-Forwarded-For").split(",")[0].strip()
        if request.headers.get("X-Real-IP"):
            return request.headers.get("X-Real-IP")
        return request.remote_addr or "0.0.0.0"

    def is_blocked(self, ip):
        """Check if IP is temporarily blocked."""
        if ip in self.blocked_ips:
            if self.blocked_ips[ip] > time.time():
                return True
            del self.blocked_ips[ip]
        return False

    def block_ip(self, ip, duration=3600):
        """Temporarily block an IP address."""
        self.blocked_ips[ip] = time.time() + duration

    def check_limit(self, endpoint=None, limit=None, window=None):
        """Check if request exceeds rate limit.
        Returns: (allowed, remaining, retry_after).
        """
        self.cleanup_old_entries()

        ip = self.get_client_ip()
        now = time.time()
        window = window or self.window_size

        # Check if IP is blocked
        if self.is_blocked(ip):
            return False, 0, self.blocked_ips.get(ip, now + 3600) - now

        # Check per-endpoint limit
        if endpoint and limit:
            endpoint_reqs = self.endpoint_requests[endpoint][ip]
            endpoint_reqs = [t for t in endpoint_reqs if now - t < window]

            if len(endpoint_reqs) >= limit:
                # Block on excessive attempts
                if len(endpoint_reqs) >= limit * 2:
                    self.block_ip(ip, 3600)  # 1 hour block
                    return False, 0, 3600
                return False, 0, window

            self.endpoint_requests[endpoint][ip] = [*endpoint_reqs, now]
            return True, limit - len(endpoint_reqs) - 1, 0

        # Check global limit
        ip_reqs = self.ip_requests[ip]
        ip_reqs = [t for t in ip_reqs if now - t < window]

        if len(ip_reqs) >= self.global_limit:
            return False, 0, window

        self.ip_requests[ip] = [*ip_reqs, now]
        return True, self.global_limit - len(ip_reqs) - 1, 0


class InputValidator:
    """Validates and sanitizes user input to prevent injection attacks."""

    @staticmethod
    def validate_string(value, max_length=1000, allow_unicode=True):
        """Validate string input."""
        if not isinstance(value, str):
            return None
        value = value.strip()
        if len(value) > max_length:
            return None
        if not allow_unicode and not value.isascii():
            return None
        return value

    @staticmethod
    def validate_email(email):
        """Validate email format."""
        import re

        if not isinstance(email, str):
            return None
        email = email.strip().lower()
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        if re.match(pattern, email) and len(email) <= 254:
            return email
        return None

    @staticmethod
    def validate_url(url):
        """Validate URL format."""
        import re

        if not isinstance(url, str):
            return None
        url = url.strip()
        pattern = r"^https?://[^\s/$.?#].[^\s]*$"
        if re.match(pattern, url, re.IGNORECASE) and len(url) <= 2048:
            return url
        return None

    @staticmethod
    def validate_integer(value, min_val=None, max_val=None):
        """Validate integer input."""
        try:
            val = int(value)
            if min_val is not None and val < min_val:
                return None
            if max_val is not None and val > max_val:
                return None
            return val
        except (ValueError, TypeError):
            return None

    @staticmethod
    def validate_float(value, min_val=None, max_val=None):
        """Validate float input."""
        try:
            val = float(value)
            if min_val is not None and val < min_val:
                return None
            if max_val is not None and val > max_val:
                return None
            return val
        except (ValueError, TypeError):
            return None

    @staticmethod
    def sanitize_filename(filename, max_length=255):
        """Sanitize filename to prevent path traversal."""
        import re

        if not isinstance(filename, str):
            return None
        filename = filename.strip()
        # Remove path separators and null bytes
        filename = re.sub(r'[/\\:\*\?"<>\|\x00]', "_", filename)
        # Remove leading/trailing dots and spaces
        filename = filename.strip(". ")
        if not filename or len(filename) > max_length:
            return None
        return filename


class CsrfProtection:
    """CSRF token generation and validation."""

    @staticmethod
    def generate_token(session_id, secret_key):
        """Generate CSRF token from session ID."""
        timestamp = str(int(time.time()))
        message = f"{session_id}:{timestamp}".encode()
        token = hmac.new(
            secret_key.encode(),
            message,
            hashlib.sha256,
        ).hexdigest()
        return f"{timestamp}.{token}"

    @staticmethod
    def validate_token(token, session_id, secret_key, max_age=3600):
        """Validate CSRF token."""
        if not token or "." not in token:
            return False

        try:
            timestamp_str, token_hash = token.split(".")
            timestamp = int(timestamp_str)
        except (ValueError, IndexError):
            return False

        # Check token age
        if time.time() - timestamp > max_age:
            return False

        # Verify token signature
        expected_message = f"{session_id}:{timestamp_str}".encode()
        expected_token = hmac.new(
            secret_key.encode(),
            expected_message,
            hashlib.sha256,
        ).hexdigest()

        return hmac.compare_digest(token_hash, expected_token)


def secure_config(app):
    """Configure Flask app with security best practices."""
    # Session security
    app.config.update(
        SESSION_COOKIE_SECURE=True,  # HTTPS only
        SESSION_COOKIE_HTTPONLY=True,  # No JavaScript access
        SESSION_COOKIE_SAMESITE="Lax",  # CSRF protection
        SESSION_COOKIE_NAME="__session_id",
        SESSION_COOKIE_PATH="/",
        PERMANENT_SESSION_LIFETIME=timedelta(hours=24),
        SESSION_REFRESH_EACH_REQUEST=True,
        PREFERRED_URL_SCHEME="https",
    )

    # Disable debug mode in production
    if not app.debug:
        app.config["ENV"] = "production"

    secret_key = os.environ.get("SECRET_KEY", "").strip()
    if not secret_key:
        generated_dir = os.path.join(
            getattr(app, "root_path", os.getcwd()),
            "generated",
        )
        os.makedirs(generated_dir, exist_ok=True)
        secret_path = os.path.join(generated_dir, "runtime_secret.key")
        try:
            with open(secret_path, encoding="utf-8") as handle:
                secret_key = handle.read().strip()
        except FileNotFoundError:
            secret_key = ""
        except OSError:
            secret_key = ""

        if not secret_key:
            secret_key = secrets.token_hex(32)
            try:
                with open(secret_path, "w", encoding="utf-8") as handle:
                    handle.write(secret_key)
                with contextlib.suppress(OSError):
                    os.chmod(secret_path, 0o600)
            except OSError:
                pass

    # Set secure cookie for admin functions
    app.secret_key = secret_key

    return app


def require_rate_limit(limiter, limit=100, window=60):
    """Decorator for rate limiting routes."""

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            allowed, _remaining, retry_after = limiter.check_limit(
                endpoint=request.endpoint,
                limit=limit,
                window=window,
            )

            if not allowed:
                return jsonify(
                    {
                        "error": "Rate limit exceeded",
                        "retry_after": int(retry_after),
                    },
                ), 429

            return f(*args, **kwargs)

        return decorated_function

    return decorator


def validate_request_data(schema):
    """Decorator for validating request data against schema."""

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            data = request.get_json() or {}

            for field, validator in schema.items():
                if field not in data:
                    return jsonify({"error": f"Missing field: {field}"}), 400

                value = data[field]
                if not validator(value):
                    return jsonify({"error": f"Invalid field: {field}"}), 400

            # Store validated data in request context
            request.validated_data = {field: data[field] for field in schema}

            return f(*args, **kwargs)

        return decorated_function

    return decorator


class SecurityHeaders:
    """Manages security headers for HTTP responses."""

    # Enhanced CSP policy with nonce support for inline scripts
    CONTENT_SECURITY_POLICY = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' "
        "https://cdnjs.cloudflare.com https://unpkg.com "
        "https://pagead2.googlesyndication.com https://partner.googleadservices.com "
        "https://googleads.g.doubleclick.net https://*.adtrafficquality.google; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com "
        "https://unpkg.com https://cdnjs.cloudflare.com; "
        "font-src 'self' https://fonts.gstatic.com data:; "
        "img-src 'self' data: blob: https: http:; "
        "media-src 'self' blob: data: https: http:; "
        "connect-src 'self' https: http:; "
        "frame-src 'self' https: http:; "
        "worker-src 'self' blob:; "
        "manifest-src 'self'; "
        "base-uri 'self'; "
        "object-src 'none'; "
        "frame-ancestors 'none'; "
        "form-action 'self'; "
        "upgrade-insecure-requests; "
        "block-all-mixed-content;"
    )

    # Additional security headers
    HEADERS = {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block; report=/api/xss-report",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": (
            "accelerometer=(), autoplay=(self), browsing-topics=(), "
            "camera=(self), fullscreen=(self), geolocation=(), "
            "gyroscope=(), magnetometer=(), microphone=(self), "
            "payment=(), usb=()"
        ),
        "Cross-Origin-Opener-Policy": "same-origin",
        "Cross-Origin-Resource-Policy": "same-site",
        "Cross-Origin-Embedder-Policy": "require-corp",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
    }

    @classmethod
    def apply_to_response(cls, response, additional_headers=None):
        """Apply security headers to Flask response."""
        response.headers["Content-Security-Policy"] = cls.CONTENT_SECURITY_POLICY
        for header, value in cls.HEADERS.items():
            response.headers[header] = value

        if additional_headers:
            for header, value in additional_headers.items():
                response.headers[header] = value

        return response


class PerformanceOptimizer:
    """Performance optimization utilities."""

    @staticmethod
    def enable_gzip_compression(app):
        """Enable GZIP compression for responses."""
        from flask_compress import Compress

        Compress(app)
        return app

    @staticmethod
    def add_cache_headers(response, cache_type="public", max_age=3600):
        """Add caching headers to response."""
        if cache_type == "public":
            response.headers["Cache-Control"] = f"public, max-age={max_age}"
        elif cache_type == "private":
            response.headers["Cache-Control"] = f"private, max-age={max_age}"
        elif cache_type == "no-cache":
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"

        return response

    @staticmethod
    def etag_response(response):
        """Add ETag to response for caching validation."""
        import hashlib

        data = response.get_data()
        etag = hashlib.md5(data).hexdigest()
        response.headers["ETag"] = f'"{etag}"'
        return response


# DDoS Protection
class DDoSProtection:
    """Advanced DDoS protection strategies."""

    def __init__(self):
        self.request_patterns = defaultdict(list)
        self.suspicious_patterns = defaultdict(int)
        self.last_pattern_check = time.time()

    def analyze_request_pattern(self, ip):
        """Detect suspicious request patterns."""
        now = time.time()

        # Check for pattern learning (every 60 seconds)
        if now - self.last_pattern_check > 60:
            self._learn_patterns()
            self.last_pattern_check = now

        self.request_patterns[ip].append(now)

        # Keep only last 60 seconds
        self.request_patterns[ip] = [
            t for t in self.request_patterns[ip] if now - t < 60
        ]

        # Check for bot-like behavior (too many requests in short time)
        if len(self.request_patterns[ip]) > 100:  # 100 req/sec
            return False

        return True

    def _learn_patterns(self):
        """Learn normal request patterns."""
        for ip, times in list(self.request_patterns.items()):
            if not times:
                continue

            # Calculate request rate
            if len(times) > 1:
                time_span = times[-1] - times[0]
                if time_span > 0:
                    rate = len(times) / time_span
                    # Flag if rate > 50 req/sec
                    if rate > 50:
                        self.suspicious_patterns[ip] += 1


# Initialize global instances
rate_limiter = RateLimiter(global_limit=1000, window_size=60)
ddos_protection = DDoSProtection()
input_validator = InputValidator()
csrf_protection = CsrfProtection()
security_headers = SecurityHeaders()
performance_optimizer = PerformanceOptimizer()
