#!/usr/bin/env python3
"""Bulk import public-domain images from Wikimedia Commons using a CSV.

CSV format (header optional): brand,model,year,query,limit,download
Example row: Toyota,Corolla,1996,"Toyota Corolla 1996",6,1

The script will search Wikimedia Commons for each query and (optionally) download
public-domain / CC0 images and create a stub manual entry in the local ManualStore.
"""

import argparse
import csv
import os
import time

from manual_store import ManualStore
from wikimedia_importer import (
    _default_session,
    download_public_domain_images,
    search_commons,
)


def run(csv_path, delay=1.0, download=False, default_limit=6, app_root=None):
    app_root = app_root or os.path.abspath(
        os.path.join(os.path.dirname(__file__), ".."),
    )
    store = ManualStore(app_root)
    session = _default_session()

    with open(csv_path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            brand = (row.get("brand") or "").strip()
            model = (row.get("model") or "").strip()
            year = (row.get("year") or "").strip()
            query = (row.get("query") or f"{brand} {model} {year}").strip()
            limit = int(row.get("limit") or default_limit)
            do_download = bool(int(row.get("download") or (1 if download else 0)))

            if not brand or not query:
                continue

            try:
                candidates = search_commons(query, limit=limit, session=session)
            except Exception:
                time.sleep(delay)
                continue

            if do_download:
                res = download_public_domain_images(
                    candidates,
                    app_root,
                    limit=limit,
                    session=session,
                )
                mid = res.get("mid")
                downloaded = res.get("downloaded", [])
                # Create a stub manual entry referencing downloaded images
                title = f"{brand} {model} {year} (Wikimedia import)"
                store.add_manual(
                    brand=brand,
                    model=model,
                    year=year,
                    title=title,
                    description="Imported Wikimedia Commons public-domain images",
                    license="various",
                    source_url=None,
                    pdf_path=None,
                    image_paths=downloaded,
                    mid=mid,
                )
            else:
                pass

            time.sleep(delay)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("csv", help="CSV file with brand,model,year,query,limit,download")
    p.add_argument(
        "--delay",
        type=float,
        default=1.0,
        help="Seconds to wait between rows",
    )
    p.add_argument(
        "--download",
        action="store_true",
        help="Download PD/CC0 images when found",
    )
    p.add_argument("--limit", type=int, default=6, help="Per-query candidate limit")
    args = p.parse_args()
    run(args.csv, delay=args.delay, download=args.download, default_limit=args.limit)


if __name__ == "__main__":
    main()
