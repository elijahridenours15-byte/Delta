#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "templates" / "_map_layer_catalog.js"
LIVE_TARGET = ROOT / "static" / "map-layer-catalog.js"
WEBSPACE_TARGET = ROOT / "webspace-site" / "assets" / "map-layer-catalog.js"


def export_catalog() -> tuple[Path, Path]:
    content = SOURCE.read_text(encoding="utf-8")
    LIVE_TARGET.parent.mkdir(parents=True, exist_ok=True)
    WEBSPACE_TARGET.parent.mkdir(parents=True, exist_ok=True)
    LIVE_TARGET.write_text(content, encoding="utf-8")
    WEBSPACE_TARGET.write_text(content, encoding="utf-8")
    return LIVE_TARGET, WEBSPACE_TARGET


def main() -> None:
    _live_target, _webspace_target = export_catalog()


if __name__ == "__main__":
    main()
