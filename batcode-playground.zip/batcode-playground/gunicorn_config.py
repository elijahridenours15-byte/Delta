# Gunicorn Configuration for Delta Coding
import multiprocessing

# Server configuration
bind = "127.0.0.1:5000"
backlog = 2048
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 50

# Server mechanics
timeout = 30
graceful_timeout = 30
keepalive = 5

# SSL configuration (if using direct SSL)
# keyfile = "/path/to/keyfile"
# certfile = "/path/to/certfile"

# Process naming
proc_name = "delta-coding"

# Logging
accesslog = "-"
errorlog = "-"
loglevel = "info"
access_log_format = (
    '%({X-Forwarded-For}i)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'
)

# Process files
pidfile = "/tmp/gunicorn.pid"


# Server hooks
def on_starting(server):
    pass


def when_ready(server):
    pass


def on_exit(server):
    pass


# Security
secure_scheme_headers = {
    "X-FORWARDED-PROTOCOL": "ssl",
    "X-FORWARDED-PROTO": "https",
    "X-FORWARDED-SSL": "on",
}

# Performance
preload_app = True
