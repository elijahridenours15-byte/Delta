#!/bin/bash
# Production deployment script for Delta Coding

set -e

echo "🚀 Delta Coding Production Deployment"

# 1. Update dependencies
echo "📦 Installing dependencies..."
pip install --upgrade -r requirements.txt

# 2. Run security checks
echo "🔒 Running security checks..."
python -c "
from security_hardening import rate_limiter, security_headers
print('✅ Security modules loaded')
print(f'   - Rate Limiter configured: {rate_limiter.global_limit} req/min')
print(f'   - Security Headers: {len(security_headers.HEADERS)} headers')
"

# 3. Run performance checks
echo "⚡ Running performance checks..."
python -c "
from performance_optimization import general_cache, query_cache
print('✅ Performance modules loaded')
print(f'   - General Cache: {general_cache.max_size} entries max')
print(f'   - Query Cache: {query_cache.cache.max_size} entries max')
"

# 4. Optimize database
echo "🗄️  Optimizing databases..."
python -c "
from performance_optimization import DatabaseOptimization
import os
for db in ['generated/journal.db', 'generated/visitors.db', 'generated/ad_inquiries.db']:
    if os.path.exists(db):
        print(f'Optimizing {db}...')
        DatabaseOptimization.optimize_db(db)
        print(f'✅ Optimized {db}')
"

# 5. Run tests
echo "🧪 Running tests..."
python -m pytest tests/ -x --tb=short

# 6. Generate production assets
echo "📊 Generating production assets..."
python scripts/build_production_bundle.py 2>/dev/null || echo "Build script not found, skipping"

# 7. Start application
echo "✅ Deployment complete!"
echo "🌐 Ready to start with: gunicorn -c gunicorn_config.py run:app"