"""Performance Optimization Module
Implements caching, database connection pooling, and response optimization.
"""

import contextlib
import sqlite3
import threading
import time
from collections import OrderedDict
from functools import wraps


class SimpleCache:
    """Simple in-memory cache with TTL support."""

    def __init__(self, max_size=1000, default_ttl=300):
        self.cache = OrderedDict()
        self.max_size = max_size
        self.default_ttl = default_ttl
        self.lock = threading.RLock()

    def set(self, key, value, ttl=None):
        """Set cache value with optional TTL."""
        with self.lock:
            ttl = ttl or self.default_ttl
            self.cache[key] = {
                "value": value,
                "expires": time.time() + ttl,
                "created": time.time(),
            }

            # Remove oldest item if cache is full
            if len(self.cache) > self.max_size:
                self.cache.popitem(last=False)

    def get(self, key):
        """Get cache value if not expired."""
        with self.lock:
            if key not in self.cache:
                return None

            entry = self.cache[key]
            if time.time() > entry["expires"]:
                del self.cache[key]
                return None

            return entry["value"]

    def delete(self, key):
        """Delete cache key."""
        with self.lock:
            if key in self.cache:
                del self.cache[key]

    def clear(self):
        """Clear entire cache."""
        with self.lock:
            self.cache.clear()

    def get_stats(self):
        """Get cache statistics."""
        with self.lock:
            size = len(self.cache)
            expired = sum(1 for v in self.cache.values() if time.time() > v["expires"])
            return {
                "size": size,
                "max_size": self.max_size,
                "expired_entries": expired,
                "hit_rate": f"{(size - expired) / max(size, 1) * 100:.1f}%",
            }


class DatabaseConnectionPool:
    """Connection pool for SQLite databases."""

    def __init__(self, db_path, pool_size=5, timeout=10):
        self.db_path = db_path
        self.pool_size = pool_size
        self.timeout = timeout
        self.connections = []
        self.available = []
        self.lock = threading.RLock()
        self._initialized = False

    def _initialize(self):
        """Initialize connection pool."""
        if self._initialized:
            return

        with self.lock:
            for _ in range(self.pool_size):
                conn = sqlite3.connect(
                    self.db_path,
                    check_same_thread=False,
                    timeout=self.timeout,
                )
                conn.isolation_level = None  # Autocommit mode
                self.connections.append(conn)
                self.available.append(conn)

            self._initialized = True

    def get_connection(self):
        """Get connection from pool."""
        self._initialize()

        start_time = time.time()
        while time.time() - start_time < self.timeout:
            with self.lock:
                if self.available:
                    return self.available.pop()
            time.sleep(0.01)

        msg = "Could not get database connection within timeout"
        raise TimeoutError(msg)

    def return_connection(self, conn):
        """Return connection to pool."""
        with self.lock:
            if conn in self.connections and conn not in self.available:
                self.available.append(conn)

    def close_all(self):
        """Close all connections in pool."""
        with self.lock:
            for conn in self.connections:
                with contextlib.suppress(Exception):
                    conn.close()
            self.connections.clear()
            self.available.clear()
            self._initialized = False


class QueryCache:
    """Caches database query results."""

    def __init__(self, cache_size=1000, ttl=300):
        self.cache = SimpleCache(max_size=cache_size, default_ttl=ttl)

    def get_or_fetch(self, query_key, query_func, ttl=None):
        """Get cached result or execute query function."""
        cached = self.cache.get(query_key)
        if cached is not None:
            return cached

        result = query_func()
        self.cache.set(query_key, result, ttl)
        return result

    def invalidate(self, pattern=None):
        """Invalidate cache entries matching pattern."""
        if pattern is None:
            self.cache.clear()
        else:
            # Simple pattern matching (startswith)
            keys_to_delete = [k for k in self.cache.cache if k.startswith(pattern)]
            for key in keys_to_delete:
                self.cache.delete(key)


class ResponseCache:
    """Caches HTTP responses for static content."""

    def __init__(self, max_size=500):
        self.cache = SimpleCache(max_size=max_size, default_ttl=3600)

    def cache_response(self, path, response, ttl=3600):
        """Cache response for a path."""
        self.cache.set(f"response:{path}", response, ttl)

    def get_cached_response(self, path):
        """Get cached response for a path."""
        return self.cache.get(f"response:{path}")

    def invalidate_path(self, path):
        """Invalidate cache for a path."""
        self.cache.delete(f"response:{path}")


class CDNHelper:
    """Helpers for CDN integration."""

    CLOUDFLARE_PURGE_URL = (
        "https://api.cloudflare.com/client/v4/zones/{zone_id}/purge_cache"
    )

    @staticmethod
    def get_cache_key(path):
        """Generate cache key for a path."""
        return f"cdn:{path}"

    @staticmethod
    def should_cache(response):
        """Check if response should be cached."""
        if response.status_code != 200:
            return False

        content_type = response.headers.get("Content-Type", "")
        cacheable_types = [
            "text/html",
            "text/css",
            "text/javascript",
            "application/javascript",
            "application/json",
            "image/png",
            "image/jpeg",
            "image/gif",
            "image/svg+xml",
            "font/woff",
            "font/woff2",
        ]

        return any(ct in content_type for ct in cacheable_types)


class DatabaseOptimization:
    """Database optimization utilities."""

    @staticmethod
    def analyze_db(db_path):
        """Analyze database for optimization opportunities."""
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        analysis = {}

        try:
            # Get table stats
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()

            analysis["tables"] = []
            for (table_name,) in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count = cursor.fetchone()[0]
                analysis["tables"].append(
                    {
                        "name": table_name,
                        "rows": count,
                    },
                )

            # Get index stats
            cursor.execute("SELECT name FROM sqlite_master WHERE type='index'")
            indexes = cursor.fetchall()
            analysis["indexes"] = [idx[0] for idx in indexes]

            # Run PRAGMA commands
            cursor.execute("PRAGMA page_count")
            analysis["page_count"] = cursor.fetchone()[0]

            cursor.execute("PRAGMA page_size")
            analysis["page_size"] = cursor.fetchone()[0]

            cursor.execute("PRAGMA freelist_count")
            analysis["freelist_count"] = cursor.fetchone()[0]

        finally:
            conn.close()

        return analysis

    @staticmethod
    def optimize_db(db_path):
        """Optimize database file."""
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        try:
            # Analyze tables for query optimization
            cursor.execute("ANALYZE")

            # Vacuum to reclaim unused space
            cursor.execute("VACUUM")

            # Reindex to update index statistics
            cursor.execute("REINDEX")

            conn.commit()
            return True
        except Exception:
            return False
        finally:
            conn.close()


def cache_decorator(ttl=300):
    """Decorator for caching function results."""
    cache = SimpleCache(default_ttl=ttl)

    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Create cache key from function name and arguments
            cache_key = f"{f.__name__}:{args!s}:{sorted(kwargs.items())!s}"

            cached = cache.get(cache_key)
            if cached is not None:
                return cached

            result = f(*args, **kwargs)
            cache.set(cache_key, result, ttl)
            return result

        return decorated_function

    return decorator


def memoize_method(f):
    """Decorator for memoizing method results."""
    cache_attr = f"_cache_{f.__name__}"

    @wraps(f)
    def decorated_function(self, *args, **kwargs):
        if not hasattr(self, cache_attr):
            setattr(self, cache_attr, SimpleCache())

        cache = getattr(self, cache_attr)
        cache_key = f"{args!s}:{sorted(kwargs.items())!s}"

        cached = cache.get(cache_key)
        if cached is not None:
            return cached

        result = f(self, *args, **kwargs)
        cache.set(cache_key, result)
        return result

    return decorated_function


class CompressionHelper:
    """Helpers for response compression."""

    COMPRESSIBLE_TYPES = {
        "text/html",
        "text/css",
        "text/javascript",
        "application/javascript",
        "application/json",
        "application/xml",
        "text/xml",
        "text/plain",
        "image/svg+xml",
    }

    @staticmethod
    def should_compress(content_type, size_min=1000):
        """Check if content should be compressed."""
        return any(ct in content_type for ct in CompressionHelper.COMPRESSIBLE_TYPES)

    @staticmethod
    def get_compression_level(size):
        """Get appropriate compression level based on size."""
        if size < 10000:
            return 6  # Balanced
        if size < 100000:
            return 7  # Better compression
        return 9  # Maximum compression


class AsyncTaskQueue:
    """Simple async task queue for non-critical operations."""

    def __init__(self, max_queue_size=1000):
        self.queue = []
        self.max_queue_size = max_queue_size
        self.lock = threading.RLock()
        self.worker_thread = None
        self.running = False

    def enqueue(self, task_func, *args, **kwargs):
        """Enqueue a task for async execution."""
        with self.lock:
            if len(self.queue) >= self.max_queue_size:
                return False  # Queue full

            self.queue.append((task_func, args, kwargs))
            return True

    def start(self):
        """Start the worker thread."""
        if self.running:
            return

        self.running = True
        self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker_thread.start()

    def stop(self):
        """Stop the worker thread."""
        self.running = False
        if self.worker_thread:
            self.worker_thread.join(timeout=5)

    def _worker_loop(self):
        """Worker loop for processing tasks."""
        while self.running:
            with self.lock:
                if not self.queue:
                    time.sleep(0.1)
                    continue

                task_func, args, kwargs = self.queue.pop(0)

            with contextlib.suppress(Exception):
                task_func(*args, **kwargs)


# Global instances
general_cache = SimpleCache(max_size=1000, default_ttl=300)
query_cache = QueryCache(cache_size=1000, ttl=300)
response_cache = ResponseCache(max_size=500)
async_queue = AsyncTaskQueue(max_queue_size=1000)
